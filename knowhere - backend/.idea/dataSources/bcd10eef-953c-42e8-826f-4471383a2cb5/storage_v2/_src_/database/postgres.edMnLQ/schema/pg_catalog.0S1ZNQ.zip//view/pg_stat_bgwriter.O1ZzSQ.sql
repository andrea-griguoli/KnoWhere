create view pg_stat_bgwriter(buffers_clean, maxwritten_clean, buffers_alloc, stats_reset) as
SELECT pg_stat_get_bgwriter_buf_written_clean() AS buffers_clean,
       pg_stat_get_bgwriter_maxwritten_clean()  AS maxwritten_clean,
       pg_stat_get_buf_alloc()                  AS buffers_alloc,
       pg_stat_get_bgwriter_stat_reset_time()   AS stats_reset;

alter table pg_stat_bgwriter
    owner to postgres;

grant select on pg_stat_bgwriter to public;

