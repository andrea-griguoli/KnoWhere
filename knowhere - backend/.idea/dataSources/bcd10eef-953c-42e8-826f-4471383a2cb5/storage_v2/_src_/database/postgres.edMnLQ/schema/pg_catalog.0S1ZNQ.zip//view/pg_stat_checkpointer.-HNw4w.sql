create view pg_stat_checkpointer
            (num_timed, num_requested, restartpoints_timed, restartpoints_req, restartpoints_done, write_time,
             sync_time, buffers_written, stats_reset)
as
SELECT pg_stat_get_checkpointer_num_timed()               AS num_timed,
       pg_stat_get_checkpointer_num_requested()           AS num_requested,
       pg_stat_get_checkpointer_restartpoints_timed()     AS restartpoints_timed,
       pg_stat_get_checkpointer_restartpoints_requested() AS restartpoints_req,
       pg_stat_get_checkpointer_restartpoints_performed() AS restartpoints_done,
       pg_stat_get_checkpointer_write_time()              AS write_time,
       pg_stat_get_checkpointer_sync_time()               AS sync_time,
       pg_stat_get_checkpointer_buffers_written()         AS buffers_written,
       pg_stat_get_checkpointer_stat_reset_time()         AS stats_reset;

alter table pg_stat_checkpointer
    owner to postgres;

grant select on pg_stat_checkpointer to public;

